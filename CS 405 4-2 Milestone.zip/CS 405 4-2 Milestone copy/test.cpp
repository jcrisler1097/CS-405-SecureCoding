//Jordan Crisler
//Professor Battle
//CS-405-10427-M01 Secure Coding 2025 C-5
//September 26, 2025

// Uncomment the next line to use precompiled headers
#include "pch.h"
// uncomment the next line if you do not use precompiled headers
//#include "gtest/gtest.h"
//
// the global test environment setup and tear down
// you should not need to change anything here
class Environment : public ::testing::Environment
{
public:
    ~Environment() override {}

    // Override this to define how to set up the environment.
    void SetUp() override
    {
        //  initialize random seed
        srand(time(nullptr));
    }

    // Override this to define how to tear down the environment.
    void TearDown() override {}
};

// create our test class to house shared data between tests
// you should not need to change anything here
class CollectionTest : public ::testing::Test
{
protected:
    // create a smart point to hold our collection
    std::unique_ptr<std::vector<int>> collection;

    void SetUp() override
    { // create a new collection to be used in the test
        collection.reset(new std::vector<int>);
    }

    void TearDown() override
    { //  erase all elements in the collection, if any remain
        collection->clear();
        // free the pointer
        collection.reset(nullptr);
    }

    // helper function to add random values from 0 to 99 count times to the collection
    void add_entries(int count)
    {
        assert(count > 0);
        for (auto i = 0; i < count; ++i)
            collection->push_back(rand() % 100);
    }
};

// When should you use the EXPECT_xxx or ASSERT_xxx macros?
// Use ASSERT when failure should terminate processing, such as the reason for the test case.
// Use EXPECT when failure should notify, but processing should continue

// Test that a collection is empty when created.
// Prior to calling this (and all other TEST_F defined methods),
//  CollectionTest::StartUp is called.
// Following this method (and all other TEST_F defined methods),
//  CollectionTest::TearDown is called
TEST_F(CollectionTest, CollectionSmartPointerIsNotNull)
{
    // is the collection created
    ASSERT_TRUE(collection);

    // if empty, the size must be 0
    ASSERT_NE(collection.get(), nullptr);
}

// Test that a collection is empty when created.
TEST_F(CollectionTest, IsEmptyOnCreate)
{
    // is the collection empty?
    ASSERT_TRUE(collection->empty());

    // if empty, the size must be 0
    ASSERT_EQ(collection->size(), 0);
}

/* Comment this test out to prevent the test from running
 * Uncomment this test to see a failure in the test explorer */
TEST_F(CollectionTest, AlwaysFail)
{
    FAIL();
}

// TODO: Create a test to verify adding a single value to an empty collection
TEST_F(CollectionTest, CanAddToEmptyVector)
{
    // is the collection empty?
    // if empty, the size must be 0
    ASSERT_TRUE(collection->empty()); //Tests if the collection is empty

    ASSERT_EQ(collection->size(), 0); //If collection is empty, size is 0

    add_entries(1);

    // is the collection still empty?
    // if not empty, what must the size be?

    ASSERT_FALSE(collection->empty()); //Tests if the collection is empty

    ASSERT_EQ(collection->size(), 1); //Tests if collection size is 1
}

// TODO: Create a test to verify adding five values to collection
TEST_F(CollectionTest, CanAddFiveValuesToVector)
{
    ASSERT_TRUE(collection->empty()); //Tests if the collection is empty

    ASSERT_EQ(collection->size(), 0); //If collection is empty, size is 0

    add_entries(5); //Adds 5 elements to the collection

    ASSERT_FALSE(collection->empty()); //Tests if the collection is empty

    ASSERT_EQ(collection->size(), 5); //Tests if collection size is 5
}

// TODO: Create a test to verify that max size is greater than or equal to size for 0, 1, 5, 10 entries
TEST_F(CollectionTest, MaxSizeGreaterThanEqualToSize) {
    add_entries(12); //Adds 12 entries

    ASSERT_TRUE(collection->max_size() >= 0); //Tests if max size is greater than or equal to 0
    ASSERT_TRUE(collection->max_size() >= 1); //Tests if max size is greater than or equal to 1
    ASSERT_TRUE(collection->max_size() >= 5); //Tests if max size is greater than or equal to 5
    ASSERT_TRUE(collection->max_size() >= 10); //Tests if max size is greater than or equal to 10
}

// TODO: Create a test to verify that capacity is greater than or equal to size for 0, 1, 5, 10 entries
TEST_F(CollectionTest, CapacityIsGreaterThanEqualToSize) {
    add_entries(12); //Adds 12 entries

    ASSERT_TRUE(collection->capacity() >= 0); //Tests if capacity is greater than or equal to 0
    ASSERT_TRUE(collection->capacity() >= 1); //Tests if capacity is greater than or equal to 1
    ASSERT_TRUE(collection->capacity() >= 5); //Tests if capacity is greater than or equal to 5
    ASSERT_TRUE(collection->capacity() >= 10); //Tests if capacity is greater than or equal to 10
}

// TODO: Create a test to verify resizing increases the collection
TEST_F(CollectionTest, VerifyResizingIncreasesCollection) {
    add_entries(2); //Addes 2 entries

    size_t collectionSize = collection->size(); //Checks collection size and stores in collectionSize variable
    collection->resize(collectionSize + 2); //Resizes collection by increasing collection by 2
    ASSERT_TRUE(collection->size() > collectionSize); //Checks to verify resizing increases the collection
}

// TODO: Create a test to verify resizing decreases the collection
TEST_F(CollectionTest, VerifyResizingDecreasesCollection) {
    add_entries(2); //Addes 2 entries

    size_t collectionSize = collection->size(); //Checks collection size and stores in collectionSize variable
    collection->resize(collectionSize - 1); //Resizes collection by decreasing by 1
    ASSERT_TRUE(collection->size() < collectionSize); //Checks to verify resizing decreases the collection
}

// TODO: Create a test to verify resizing decreases the collection to zero
TEST_F(CollectionTest, VerifyResizingDecreasesCollectionToZero) {
    add_entries(2); //Addes 2 entries

    size_t collectionSize = collection->size(); //Checks collection size and stores in collectionSize variable
    collection->resize(0); //Resizes collection to 0
    ASSERT_TRUE(collection->size() == 0); //Checks to verify resizing decreases the collection to 0
}

// TODO: Create a test to verify clear erases the collection
TEST_F(CollectionTest, VerifyClearErasesCollection) {
    add_entries(2); //Addes 2 entries

    collection->clear(); //Clears collection
    ASSERT_TRUE(collection->size() == 0); //Checks to verify collection has been cleared
}

// TODO: Create a test to verify erase(begin,end) erases the collection
TEST_F(CollectionTest, VerifyEraseErasesCollection) {
    add_entries(2); //Addes 2 entries

    collection->erase(collection->begin(),collection->end()); //Erases collection
    ASSERT_TRUE(collection->size() == 0); //Checks to verify collection has been erased
}

// TODO: Create a test to verify reserve increases the capacity but not the size of the collection
TEST_F(CollectionTest, VerifyReserveIncreasesCapacityButNotSizeCollection) {
    add_entries(2); //Addes 2 entries

    size_t collectionSize = collection->size(); //Checks collection size and assigns to variable collectionSize
    size_t collectionCapacity = collection->capacity(); //Checks collection capacity and assigns to variable collectionCapacity

    ASSERT_FALSE(collectionCapacity == collection->max_size()); //Checks if collectionCapacity equals collection max size, because collection capacity can't increase above max size

    collection->reserve(collectionCapacity + 1); //Increases reserve capacity by 1
    ASSERT_TRUE(collection->size() == collectionSize); //Checks if collection size still equals original collectionSize
    ASSERT_TRUE(collection->capacity() > collectionCapacity); //Checks if collection capacity is increased
}

// TODO: Create a test to verify the std::out_of_range exception is thrown when calling at() with an index out of bounds
// NOTE: This is a negative test
TEST_F(CollectionTest, VerifyExceptionThrownWhenCallingAt) {
    add_entries(2); //Addes 2 entries

    size_t collectionSize = collection->size(); //Checks collection size and assigns to variable collectionSize
    ASSERT_THROW(collection->at(collectionSize + 1), std::out_of_range); //Throws std::out_of_range exception when calling at() with index out of bounds
}

// TODO: Create 2 unit tests of your own to test something on the collection - do 1 positive & 1 negative
//Unit test 1 
TEST_F(CollectionTest, TestCollectionPopBack) {
    add_entries(2); //Addes 2 entries - positive test

    size_t collectionSize = collection->size(); //Checks size of collection and assigns to variable collectonSize

    collection->pop_back(); //Calls pop_back() function
    ASSERT_TRUE(collection->size() == collectionSize); //Checkif collection size is equal to collectionSize
}

//Unit test 2 - negative test
TEST_F(CollectionTest, VerifyIncreaseReserveAboveCollectionMaxSize) {
    add_entries(2); //Addes 2 entries

    ASSERT_THROW(collection->reserve(collection->max_size() + 5), std::length_error); //Checks if reserve is increased above collection max size

}